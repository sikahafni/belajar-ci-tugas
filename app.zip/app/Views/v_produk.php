<?= $this->extend('layout') ?> <!-- hanya satu extend -->
<?= $this->section('content') ?> <!-- buka section -->
    Ini halaman produk
<?= $this->endSection() ?> <!-- tutup section -->
